-- Create the sales table
CREATE TABLE sales (
    region VARCHAR2(50),
    product VARCHAR2(50),
    year NUMBER,
    quarter NUMBER,
    amount NUMBER
);

-- Insert data into the sales table
INSERT INTO sales VALUES('North','Product A',2020,1,1000);
INSERT INTO sales VALUES('North','Product B',2020,1,1500);
INSERT INTO sales VALUES('North','Product A',2020,2,1200);
INSERT INTO sales VALUES('North','Product B',2020,2,1800);
INSERT INTO sales VALUES('South','Product A',2020,1,900);
INSERT INTO sales VALUES('South','Product B',2020,1,1300);
INSERT INTO sales VALUES('South','Product A',2020,2,1100);
INSERT INTO sales VALUES('South','Product B',2020,2,1700);
COMMIT;

-- Query to select all data from the sales table
SELECT * FROM sales;

-- Slice: Retrieve all records from the 'North' region
SELECT * FROM sales WHERE region = 'North';

-- Dice: Retrieve records from the 'North' region for 'Product A'
SELECT * FROM sales WHERE region = 'North' AND product = 'Product A';

-- Drilldown (Roll Down): Summarize total amounts by region, product, and year using ROLLUP
SELECT region, product, year, SUM(amount) AS total_amount 
FROM sales 
GROUP BY ROLLUP(region, product, year);

-- Rollup (Drill Up): Summarize total amounts by region and product without considering years
SELECT region, product, SUM(amount) AS total_amount 
FROM sales 
GROUP BY ROLLUP(region, product);

-- Pivot (Rotate): Pivot the data to display each quarter's amount in separate columns
SELECT * FROM (
    SELECT region , product, quarter, amount FROM sales
) PIVOT (
    SUM(amount) FOR quarter IN (1 AS Q1, 2 AS Q2)
);