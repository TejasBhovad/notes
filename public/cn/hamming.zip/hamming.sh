#!/bin/bash

# Create a directory for the C program
folder_name="hamming"
mkdir -p "$folder_name"
cd "$folder_name" || exit

# Create the C program file
cat <<EOL > hamming.c
#include <stdio.h>

int main() {
    int data[12] = {0};
    int received[12];
    int i;
    
 
    printf("Enter 4 bits of data: ");
    scanf("%d", &data[2]);  
    scanf("%d", &data[4]); 
    scanf("%d", &data[5]);   
    scanf("%d", &data[6]);  
 
    data[0] = data[2] ^ data[4] ^ data[6];

    data[1] = data[2] ^ data[5] ^ data[6]; 
    data[3] = data[4] ^ data[5] ^ data[6];
    
    printf("\nEncoded Hamming code: ");
    for(i = 0; i < 7; i++) {
        printf("%d ", data[i]);
    }
    printf("\n");
    
    printf("\nEnter received 7-bit code: ");
    for(i = 0; i < 7; i++) {
        scanf("%d", &received[i]);
    } 
    int c1 = received[0] ^ received[2] ^ received[4] ^ received[6];
    int c2 = received[1] ^ received[2] ^ received[5] ^ received[6];
    int c3 = received[3] ^ received[4] ^ received[5] ^ received[6];
    
    int error_pos = c1 * 1 + c2 * 2 + c3 * 4;
    
    if(error_pos == 0) {
        printf("\nNo error found\n");
    } else {
        printf("\nError detected at pos %d\n", error_pos - 1); 
        received[error_pos - 1] = !received[error_pos - 1];
        
        printf("Corrected code is  : ");
        for(i = 0; i < 7; i++) {
            printf("%d ", received[i]);
        }
        printf("\n");
        
        printf("Original data  : %d %d %d %d\n", 
               received[2], received[4], received[5], received[6]);
    }
    
    return 0;
}
EOL

# Compile the C program
gcc hamming.c -o hamming

# Print instructions to run the program
echo ""
echo "Setup complete!"
echo "To run the program, execute:"
echo "  ./hamming"
echo ""

# Wait for 5 seconds before clearing the terminal
sleep 5

# Clear the terminal
clear

# Delete command history (optional)
history -c


# Move to the parent directory to delete this script file
cd .. || exit

# Delete this script file after execution
rm -- "$0"
 