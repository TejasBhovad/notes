#!/bin/bash

# Create a directory for the C program
folder_name="hamming"
mkdir -p "$folder_name"
cd "$folder_name" || exit

# Create the C program file
cat <<EOL > hamming.c
#include <stdio.h>

int main() {
    int data[8];
    int c1, c2, c3;
    int i;
    int dataatrec[8]; // Change size to 8 since we are receiving 8 bits

    printf("Enter 4 bits of data: ");
    for(i = 0; i < 4; i++) {
        scanf("%d", &data[i]);
    }

    // Calculate parity bits
    data[4] = data[0] ^ data[1] ^ data[2];
    data[5] = data[0] ^ data[1] ^ data[3];
    data[6] = data[0];
    data[7] = data[1];

    printf("Encoded data: ");
    for(i = 0; i < 8; i++) {
        printf("%d ", data[i]);
    }
    printf("\\n");

    printf("Enter received data: ");
    for(i = 0; i < 8; i++) {
        scanf("%d", &dataatrec[i]);
    }

    // Calculate syndrome bits
    c1 = dataatrec[4] ^ dataatrec[0] ^ dataatrec[1] ^ dataatrec[2];
    c2 = dataatrec[5] ^ dataatrec[0] ^ dataatrec[1] ^ dataatrec[3];
    c3 = dataatrec[6] ^ dataatrec[0];

    int error_position = c1 + c2 * 2 + c3 * 4 - 1;

    if(error_position != -1) { // If error position is -1, no error detected
        printf("Error at position: %d\\n", error_position + 1);
        dataatrec[error_position] = 1 - dataatrec[error_position]; // Correct the error
        printf("Corrected data: ");
        for(i = 0; i < 8; i++) {
            printf("%d ", dataatrec[i]);
        }
    } else {
        printf("\\n");
        printf("No error detected.\\n");
    }

    return 0;
}
EOL

# Compile the C program
gcc hamming.c -o hamming

# Print instructions to run the program
echo ""
echo "Setup complete!"
echo "To run the program, execute:"
echo "  ./hamming"
echo ""

# Wait for 5 seconds before clearing the terminal
sleep 5

# Clear the terminal
clear

# Delete command history (optional)
history -c

# Inform user that history has been cleared
echo "Terminal cleared and command history deleted."

# Move to the parent directory to delete this script file
cd .. || exit

# Delete this script file after execution
rm -- "$0"

# Inform user that the script has been deleted
echo "The setup script has been deleted."