# Basic Networking commands
sudo apt update
sudo apt upgrade
sudo apt install net-tools
sudo apt install traceroute

ifconfig

ping facebook.com

tracepath google.com

dig youtube.com 

traceroute -m 5 youtube.com

nslookup
youtube.com
instagram.com
facebook.com

host 

ip addr