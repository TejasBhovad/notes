## Setting Up Multiple IP Addresses

### Add an IP Address
```bash
sudo ip addr add 192.168.1.100/24 dev eth0
```

### Verify Configuration
```bash
ip addr show eth0
```

### Remove an IP Address
```bash
sudo ip addr del 192.168.1.100/24 dev eth0
```

## Viewing Current Routing Table

### Using netstat
```bash
netstat -rn
```

### Using route
```bash
route -n
```

### Add a Route
```bash
sudo ip route add 10.0.0.0/24 via 192.168.1.1 dev eth0
```

### Delete a Route
```bash
sudo ip route del 10.0.0.0/24
```
### Change Default Gateway
```bash
sudo ip route change default via 192.168.1.1
```
 
 