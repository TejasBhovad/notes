 ### Step 1: Install Telnet
- Open your terminal and type:
  ```bash
  sudo apt install telnetd
  ```

### Step 2: Check Service Status
- To see if the service is running, type:
  ```bash
  sudo systemctl status inetd
  ```

### Step 3: Allow Connections
- Make sure connections are allowed on port 23 by typing:
  ```bash
  sudo ufw allow 23/tcp
  ```

### Step 4: Connect Using Telnet
- To connect to a remote server, type:
  ```bash
  telnet [IP]
  ```
  Replace `[IP]` with the actual IP address of the server.

---

### After Connecting
- Once you run the telnet command, you will be prompted to enter your username and password. Simply type them in when asked.
 
 