## Step 1: Install vsftpd
To install the FTP server software, open your terminal and run the following command:

```bash
sudo apt install vsftpd
```

## Step 2: Allow FTP Connections
Next, you need to allow FTP connections through your firewall. Run these commands:

```bash
sudo ufw allow 21/tcp
sudo ufw allow 20/tcp
```

- **Port 21** is used for FTP control.
- **Port 20** is used for FTP data transfer.

## Step 3: Configure vsftpd
Now, you need to configure the FTP server settings. Open the configuration file with this command:

```bash
sudo nano /etc/vsftpd.conf
```

### Changes to Make:
- **Enable Anonymous Access**: Change `anonymous_enable=NO` to `anonymous_enable=YES` if you want to allow anonymous users.
- **Enable Write Access**: Change `write_enable=NO` to `write_enable=YES` if you want users to be able to upload files.

### Save and Exit:
- To save your changes, press **Control + O**, then press **Enter**.
- To exit the editor, press **Control + X**.

## Step 4: Restart vsftpd Service
After making changes, restart the vsftpd service to apply them:

```bash
sudo systemctl restart vsftpd
```

---
 
### Connect to the FTP Server
Open your terminal and type:

```bash
ftp <IP>
```
Replace `<IP>` with the actual IP address of the server you want to connect to. If a login is required, enter your username and password when prompted.

### List Files in the Directory
Once connected, you can list files in the current directory by typing:

```bash
ls
```

### Download Files
To download a file from the server, use the command:

```bash
mget <file_name>
```
Replace `<file_name>` with the name of the file you want to download.

 