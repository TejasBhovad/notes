#!/bin/bash

# Define an array of possible directory names
dir_names=("cn" "CN" "socket" "exp" "new folder")

# Select a random name from the array
random_index=$((RANDOM % ${#dir_names[@]}))
folder_name="${dir_names[$random_index]}"

# Create the directory and navigate into it
mkdir "$folder_name"
cd "$folder_name" || exit

# Update package index and install default JDK
echo "Installing Java Development Kit..."
sudo apt update
sudo apt install -y default-jdk

# Create Java files with random indentation and human-readable variable names
echo "Creating Java files..."

# Create MyServer.java with random indentation
cat <<EOL > MyServer.java
import java.io.*;
import java.net.*;

public class MyServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(6666);
            System.out.println("Server is running and waiting for connections...");
            Socket clientSocket = serverSocket.accept(); // Establishes Connection
            DataInputStream dataInputStream = new DataInputStream(clientSocket.getInputStream());
            String receivedMessage = (String) dataInputStream.readUTF();
            System.out.println("Message= " + receivedMessage);
            clientSocket.close();
            serverSocket.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
EOL

# Create MyClient1.java with random indentation
cat <<EOL > MyClient1.java
import java.io.*;
import java.net.*;

public class MyClient1 {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 6666);
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeUTF("Hello Server");
                dataOutputStream.flush();
                dataOutputStream.close();
                socket.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
EOL

# Create MyClient2.java with random indentation
cat <<EOL > MyClient2.java
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class MyClient2 {
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            Socket socket = new Socket("localhost", 6666);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                System.out.println("Enter the String: ");
                String userInput = scanner.nextLine();
                dataOutputStream.writeUTF(userInput);
                dataOutputStream.flush();
                dataOutputStream.close();
                socket.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
EOL

# Compile Java files
echo "Compiling Java files..."
javac MyServer.java MyClient1.java MyClient2.java

# Print instructions to run the server and clients
echo ""
echo "Setup complete!"
echo "To run the server, execute:"
echo "  java MyServer"
echo ""
echo "To run Client 1, open another terminal and execute:"
echo "  java MyClient1"
echo ""
echo "To run Client 2, open another terminal and execute:"
echo "  java MyClient2"
echo ""
echo "Make sure to run the server first before running the clients."

# Wait for 5 seconds before clearing the terminal
sleep 5

# Clear the terminal
clear

# Delete command history (optional)
history -c

# Inform user that history has been cleared
echo "Terminal cleared and command history deleted."

# Move to the parent directory to delete this script file
cd .. || exit

# Delete this script file after execution
rm -- "$0"

# Inform user that the script has been deleted
echo "The setup script has been deleted."