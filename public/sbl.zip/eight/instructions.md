install docker desktop
install docker_2.sh
navigate to file containing docker_2.sh (cd Downloads)
run 
- chmod +x docker_2.sh
- ./docker_2.sh