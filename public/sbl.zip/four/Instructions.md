For installing jenkins install java 17 or java 21
install jenkins

Java link: https://www.oracle.com/in/java/technologies/downloads/#java21

Jenkins(https://www.jenkins.io/download): 
java -jar jenkins.war (using Java)
or use the installer 


Process: 
new item > select pipeline > under script (select hello world OR any other programs from dub.sh/rait) > Save the script > build now > console output

