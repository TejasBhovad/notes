install tomcat
install jenkins
move war file to webapps folder of tomcat installation
go to bin of tomcat and run startup.bat folder
go to localhost:8080