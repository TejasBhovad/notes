install docker desktop
install docker_1.sh
navigate to file containing docker_1.sh (cd Downloads)
run 
- chmod +x docker_1.sh
- ./docker_1.sh